import requests
from bs4 import BeautifulSoup
from article_addon import Article, get_elem

response=requests.get('https://www.morningbrew.com/latest/')
# Split response HTML at 'main' tag, and split second member of split array into
# articles based on horizontal line ('hr') 
m=response.text.split('<main')[1].split('<hr')
# Collection of article objects
collection=[]
# For each atricle find requested elements
for n  in m:
    soup=BeautifulSoup(n,'html.parser')
    # Category
    cat=get_elem(soup,'td','class',"tag-inner")
    # Title
    title=get_elem(soup,"h1")
    # print (title)
    # Content - plain text and HTML content
    if title==None:
        content1=str(soup.find('td', {'class':'section body-copy'}).p.extract())
        
    else:
        content1=str(soup.findAll('td', {'class':'section body-copy'})[1])
    
    content_html=content1
    content_text=BeautifulSoup(content1,'html.parser').text
    
    # Array of images URLs
    imgs=[]
    images=soup.findAll('img')
    # List of strings to exclude images if contains 
    icons=['facebook_icon','twitter_icon','linkedin_icon','mail_icon','csimport']
    # Presence of strigs from 'icons' list in URL of image
    pres=False
    for image1 in images:
        for icon1 in icons:
            if icon1  in str(image1['src']):
                pres=True
                break        
        if pres==False:
            imgs.append(image1['src'])
    
    collection.append(Article(cat,title,content_text,content_html,imgs) )

# Example of what is in object as result    
for s in collection:
    print('*********')
    print ('Category: ' + str(s.category))
    print ('Title: ' + str(s.title)) 
    print ('Images URL: ' + str(s.images))   
    print ('Text: ' + str(s.contentT))
    print ('HTML: ' + str(s.contentH)) 
    print('*********')
