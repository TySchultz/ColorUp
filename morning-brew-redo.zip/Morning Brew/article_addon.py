def get_elem(soup,elment,attrib=0,val=0):
    if attrib==0:
        try:
            nst=soup.find(elment).text
            return nst
        except:
            pass

    elif attrib != 0:
        try:
            nst=soup.find(elment,{attrib: val}).text
            return nst
        except:
            pass
        try:
            nst=soup.find(elment,{attrib: val + "-sponsored"}).text
            return nst
        except:
            pass

class Article:
    def __init__(self, category, title, contentT, contentH, images):
        self.category=category
        self.title=title
        self.contentT=contentT
        self.contentH=contentH
        self.images=images

